import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Star, MapPin, Phone, Clock, Users, CheckCircle, Facebook, Menu, X, HelpCircle, Play } from "lucide-react";
import { useState, useEffect } from "react";
import { MapView } from "@/components/Map";
import { BookingForm } from "@/components/BookingForm";
import { CarSlider } from "@/components/CarSlider";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

/**
 * MMSU Driving School Landing Page - iOS 26 Edition
 * Design Philosophy: Premium iOS 26 Aesthetic with Red Accent
 * - Glassmorphism effects with soft shadows
 * - Red color palette (#dc2626 primary, #f87171 secondary)
 * - Smooth animations and micro-interactions
 * - Rounded corners with depth (1.25rem radius)
 * - Professional typography with Poppins & Inter
 */

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showFloatingCTA, setShowFloatingCTA] = useState(false);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const PHONE_NUMBER = "09483335035";
  const DISPLAY_PHONE = "0948 333 5035";
  const EMAIL = "mmsudriving@gmail.com";
  const EXECUTIVE_EMAIL = "mmsu.executive@gmail.com";

  // Add structured data for SEO
  useEffect(() => {
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "MMSU Driving School",
      "description": "Professional driving school offering certified driving lessons in Biñan, Pasay, Calamba, and Las Piñas",
      "url": "https://mmsudriving.com",
      "telephone": "+639483335035",
      "email": EMAIL,
      "image": "https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/mmsu2_5a2738c2.jpg",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Biñan",
        "addressRegion": "Laguna",
        "addressCountry": "PH"
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.9",
        "ratingCount": "500"
      }
    };
    
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(structuredData);
    document.head.appendChild(script);
    
    return () => {
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
    };
  }, []);

  // Show floating CTA button after scrolling 300px
  useEffect(() => {
    const handleScroll = () => {
      setShowFloatingCTA(window.scrollY > 300);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: "smooth" });
    setIsMenuOpen(false);
  };

  const handleCall = () => {
    window.location.href = `tel:${PHONE_NUMBER}`;
  };

  const faqs = [
    {
      question: "How long does each lesson take?",
      answer: "Each standard driving lesson typically takes 1 to 2 hours, depending on your chosen course and schedule. We recommend 2-hour sessions for better skill retention."
    },
    {
      question: "What if I fail the road test?",
      answer: "Don't worry! Many students need more than one try. We offer discounted refresher sessions specifically focused on the areas where you struggled to help you pass on your next attempt."
    },
    {
      question: "Can I reschedule my lessons?",
      answer: "Yes, you can reschedule your lessons. We ask for at least 24 hours' notice so we can adjust our instructors' schedules and offer the slot to another student."
    },
    {
      question: "Do I need my own car for the lessons?",
      answer: "No, we provide well-maintained, dual-control vehicles for all our lessons to ensure your safety and meet LTO requirements."
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Booking Form Modal */}
      <BookingForm isOpen={isBookingOpen} onOpenChange={setIsBookingOpen} />

      {/* Navigation Header */}
      <header className="sticky top-0 z-40 glass border-b border-white/20">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg overflow-hidden flex-shrink-0">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/mmsu2_5a2738c2.jpg" alt="MMSU Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900">MMSU</h1>
              <p className="text-xs text-red-600 font-semibold">Driving School</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection("hero")} className="text-sm font-medium text-slate-600 hover:text-red-600 transition-colors">Home</button>
            <button onClick={() => scrollToSection("services")} className="text-sm font-medium text-slate-600 hover:text-red-600 transition-colors">Services</button>
            <button onClick={() => scrollToSection("faq")} className="text-sm font-medium text-slate-600 hover:text-red-600 transition-colors">FAQ</button>
            <button onClick={() => scrollToSection("reviews")} className="text-sm font-medium text-slate-600 hover:text-red-600 transition-colors">Reviews</button>
            <button onClick={() => scrollToSection("location")} className="text-sm font-medium text-slate-600 hover:text-red-600 transition-colors">Location</button>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:block">
            <Button 
              onClick={() => setIsBookingOpen(true)}
              className="bg-red-600 hover:bg-red-700 text-white rounded-full px-6 hover-scale shadow-lg font-semibold"
            >
              Book Your First Lesson
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 hover:bg-slate-100 rounded-xl transition-colors"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-white/20 bg-white/95 backdrop-blur-sm">
            <nav className="container py-4 flex flex-col gap-4">
              <button onClick={() => scrollToSection("hero")} className="text-left text-sm font-medium text-slate-600 hover:text-red-600 py-2">Home</button>
              <button onClick={() => scrollToSection("services")} className="text-left text-sm font-medium text-slate-600 hover:text-red-600 py-2">Services</button>
              <button onClick={() => scrollToSection("faq")} className="text-left text-sm font-medium text-slate-600 hover:text-red-600 py-2">FAQ</button>
              <button onClick={() => scrollToSection("reviews")} className="text-left text-sm font-medium text-slate-600 hover:text-red-600 py-2">Reviews</button>
              <button onClick={() => scrollToSection("location")} className="text-left text-sm font-medium text-slate-600 hover:text-red-600 py-2">Location</button>
              <Button 
                onClick={() => setIsBookingOpen(true)}
                className="w-full bg-red-600 hover:bg-red-700 text-white rounded-full mt-2 font-semibold"
              >
                Book Your First Lesson
              </Button>
            </nav>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section id="hero" className="relative py-12 md:py-24 bg-gradient-to-br from-slate-50 via-white to-red-50 overflow-hidden">
        {/* Decorative Blobs */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-red-100 rounded-full mix-blend-multiply filter blur-3xl opacity-20 -mr-48 -mt-48"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-red-50 rounded-full mix-blend-multiply filter blur-3xl opacity-20 -ml-48 -mb-48"></div>

        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left: Text Content */}
            <div className="space-y-8 animate-fade-in-up">
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl font-bold text-slate-900 leading-tight">
                  Learn to Drive with <span className="bg-gradient-to-r from-red-600 to-red-500 bg-clip-text text-transparent">Confidence</span> in Biñan
                </h1>
                <p className="text-lg text-slate-600">
                  Affordable, beginner-friendly driving lessons with certified instructors. Build your skills at your own pace.
                </p>
              </div>

              {/* Trust Indicators */}
              <div className="flex flex-col sm:flex-row gap-6">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={18} className={i < 4 ? "fill-amber-400 text-amber-400" : "fill-amber-200 text-amber-200"} />
                    ))}
                  </div>
                  <span className="font-semibold text-slate-900">4.9 Rating</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600">
                  <Users size={20} className="text-red-600" />
                  <span>500+ Happy Students</span>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button 
                  onClick={() => setIsBookingOpen(true)}
                  className="bg-red-600 hover:bg-red-700 text-white rounded-full px-8 py-6 text-base font-semibold hover-scale shadow-lg"
                >
                  Book Your First Lesson
                </Button>
                <Button 
                  variant="outline" 
                  onClick={handleCall}
                  className="border-2 border-red-600 text-red-600 hover:bg-red-50 rounded-full px-8 py-6 text-base font-semibold hover-scale"
                >
                  Call Now: {DISPLAY_PHONE}
                </Button>
              </div>
            </div>

            {/* Right: Hero Image */}
            <div className="relative">
              <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516621194/gDdEJPktTbcDH5myMzucGb/hero-driving-lesson-mtEAqvYCyqnWiit9CDWmgw.webp"
                  alt="Confident driver in car"
                  className="w-full h-auto object-cover"
                />
              </div>
              {/* Decorative Card */}
              <div className="absolute -bottom-6 -left-6 glass rounded-2xl p-4 z-20 hidden sm:block">
                <p className="text-sm font-semibold text-slate-900">Professional Instructors</p>
                <p className="text-xs text-slate-600">Certified & Experienced</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-16 md:py-24 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">What Our Students Say</h2>
            <p className="text-lg text-slate-600">Join hundreds of confident drivers who started with us</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <Card className="border-0 shadow-soft hover-lift rounded-2xl glass">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/maria-santos-profile-2Ynsen5ejgm5MZFzsfc7To.webp" alt="Maria Santos" className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <p className="font-semibold text-slate-900">Maria Santos</p>
                      <p className="text-xs text-slate-600">Beginner course</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  "The instructors are so patient and supportive. I was nervous at first, but they made me feel confident. Highly recommended!"
                </p>
              </CardContent>
            </Card>

            {/* Testimonial 2 */}
            <Card className="border-0 shadow-soft hover-lift rounded-2xl glass">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/juan-dela-cruz-profile-R7F39pDGBks3H8AzPdA3xX.webp" alt="Juan Dela Cruz" className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <p className="font-semibold text-slate-900">Juan Dela Cruz</p>
                      <p className="text-xs text-slate-600">Refresher course</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  "Great value for money. The flexible schedule worked perfectly with my work. Professional and friendly service!"
                </p>
              </CardContent>
            </Card>

            {/* Testimonial 3 */}
            <Card className="border-0 shadow-soft hover-lift rounded-2xl glass">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/ana-reyes-profile-nu2TifctqbiW3uB6VdSPbj.webp" alt="Ana Reyes" className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <p className="font-semibold text-slate-900">Ana Reyes</p>
                      <p className="text-xs text-slate-600">Road test prep</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  "The road test preparation was thorough and realistic. I felt completely ready on exam day. Passed with flying colors!"
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Students Choose Us / Video & FAQ Section */}
      <section id="faq" className="py-12 md:py-24 bg-slate-50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 items-start">
            {/* Left: Video Section */}
            <div className="space-y-6 md:space-y-8">
              <div>
                <h2 className="text-2xl md:text-4xl font-bold text-slate-900 mb-4 md:mb-6">Why Students Choose Us</h2>
                
                {/* Facebook Video Embed */}
                <div className="relative w-full rounded-2xl md:rounded-3xl overflow-hidden shadow-lg md:shadow-2xl group cursor-pointer bg-slate-900" style={{ paddingBottom: '56.25%' }}>
                  <iframe
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                    }}
                    src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2Fmmsudscalamba%2Fvideos%2F1033393780545694&show_text=false&width=500"
                    frameBorder="0"
                    allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
                    allowFullScreen={true}
                    scrolling="no"
                  ></iframe>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3 md:gap-4">
                <div className="p-3 md:p-4 glass rounded-xl md:rounded-2xl border border-white/20">
                  <p className="text-xl md:text-2xl font-bold text-red-600">98%</p>
                  <p className="text-xs md:text-sm text-slate-600">Pass Rate</p>
                </div>
                <div className="p-3 md:p-4 glass rounded-xl md:rounded-2xl border border-white/20">
                  <p className="text-xl md:text-2xl font-bold text-red-600">500+</p>
                  <p className="text-xs md:text-sm text-slate-600">Students</p>
                </div>
              </div>
            </div>

            {/* Right: FAQ Accordion */}
            <div className="space-y-6 md:space-y-8">
              <div className="flex items-center gap-3 mb-2">
                <HelpCircle className="text-red-600" size={24} />
                <h2 className="text-2xl md:text-3xl font-bold text-slate-900">Common Questions</h2>
              </div>
              
              <Accordion type="single" collapsible className="w-full space-y-4">
                {faqs.map((faq, index) => (
                  <AccordionItem 
                    key={index} 
                    value={`item-${index}`}
                    className="glass rounded-2xl px-6 border border-white/20 overflow-hidden"
                  >
                    <AccordionTrigger className="text-base font-semibold text-slate-900 hover:no-underline py-5">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-slate-600 pb-5 leading-relaxed">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
              
              <div className="pt-4">
                <Button 
                  onClick={() => scrollToSection("location")}
                  variant="link" 
                  className="text-red-600 font-semibold p-0 h-auto hover:text-red-700"
                >
                  Still have questions? Contact us directly →
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-red-50 to-red-100/50">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Why Choose MMSU?</h2>
                <p className="text-lg text-slate-600">
                  We're committed to making you a confident, safe driver. Our proven methods have helped hundreds of students succeed.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="w-6 h-6 text-red-600 mt-1" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">Certified Instructors</h3>
                    <p className="text-slate-600">All instructors are professionally certified with years of experience</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="w-6 h-6 text-red-600 mt-1" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">Flexible Schedules</h3>
                    <p className="text-slate-600">Book lessons that fit your lifestyle - weekdays, weekends, mornings, or evenings</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="w-6 h-6 text-red-600 mt-1" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">Beginner-Friendly</h3>
                    <p className="text-slate-600">No experience needed. We start from the basics and build your confidence</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="w-6 h-6 text-red-600 mt-1" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">Affordable Rates</h3>
                    <p className="text-slate-600">Transparent pricing with no hidden fees. Great value for quality instruction</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="glass rounded-3xl p-8 border border-white/20">
              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-4xl font-bold text-red-600 mb-2">500+</div>
                  <p className="text-slate-600">Happy Students Trained</p>
                </div>
                <div className="h-px bg-white/20"></div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-red-600 mb-2">98%</div>
                  <p className="text-slate-600">Pass Rate on Road Tests</p>
                </div>
                <div className="h-px bg-white/20"></div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-red-600 mb-2">10+</div>
                  <p className="text-slate-600">Years of Experience</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section - Three Courses */}
      <section id="services" className="py-16 md:py-24 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Our Courses</h2>
            <p className="text-lg text-slate-600">Choose the course that fits your needs</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Course 1: Theoretical Driving Course */}
            <Card className="border-0 shadow-soft hover-lift rounded-2xl overflow-hidden group glass">
              <div className="relative h-48 overflow-hidden bg-gradient-to-br from-red-100 to-red-200">
                <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/theoretical-course-ftEtyaJmKXXip9wME8LYqL.webp" alt="Theoretical Course" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl text-slate-900">Theoretical Driving Course</CardTitle>
                <CardDescription className="text-base">15-hour session</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <ul className="space-y-3 text-slate-600">
                  <li className="flex gap-3">
                    <CheckCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Onsite for three to five days</span>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Comprehensive theory coverage</span>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Expert instructors</span>
                  </li>
                </ul>
                <Button 
                  onClick={() => setIsBookingOpen(true)}
                  className="w-full bg-red-600 hover:bg-red-700 text-white rounded-full py-6 font-semibold hover-scale"
                >
                  Book Now
                </Button>
              </CardContent>
            </Card>

            {/* Course 2: Online Theoretical Driving Course */}
            <Card className="border-0 shadow-soft hover-lift rounded-2xl overflow-hidden group glass">
              <div className="relative h-48 overflow-hidden bg-gradient-to-br from-red-100 to-red-200">
                <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/online-theoretical-course-7ttaf5HsdVjK3YF5cDBBBs.webp" alt="Online Theoretical Course" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl text-slate-900">Online Theoretical Course</CardTitle>
                <CardDescription className="text-base">15-hour session</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <ul className="space-y-3 text-slate-600">
                  <li className="flex gap-3">
                    <CheckCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Learn at your own pace</span>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Flexible schedule</span>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                    <span>24/7 access to materials</span>
                  </li>
                </ul>
                <Button 
                  onClick={() => setIsBookingOpen(true)}
                  className="w-full bg-red-600 hover:bg-red-700 text-white rounded-full py-6 font-semibold hover-scale"
                >
                  Book Now
                </Button>
              </CardContent>
            </Card>

            {/* Course 3: Practical Driving Course */}
            <Card className="border-0 shadow-soft hover-lift rounded-2xl overflow-hidden group glass">
              <div className="relative h-48 overflow-hidden bg-gradient-to-br from-red-100 to-red-200">
                <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/practical-driving-course-WEecrppFCmNPtn7i2smweS.webp" alt="Practical Driving Course" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl text-slate-900">Practical Driving Course</CardTitle>
                <CardDescription className="text-base">Eight-hour session</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <ul className="space-y-3 text-slate-600">
                  <li className="flex gap-3">
                    <CheckCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Two days of on-road assessment</span>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Real-world driving experience</span>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Certified dual-control vehicles</span>
                  </li>
                </ul>
                <Button 
                  onClick={() => setIsBookingOpen(true)}
                  className="w-full bg-red-600 hover:bg-red-700 text-white rounded-full py-6 font-semibold hover-scale"
                >
                  Book Now
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* PDC Cars Available Section */}
      <section id="cars" className="py-16 md:py-24 bg-gradient-to-b from-slate-50 to-white">
        <div className="container">
          <CarSlider />
        </div>
      </section>

      {/* Testimonials / Reviews Section */}
      <section id="reviews" className="py-16 md:py-24 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Hear From Our Successful Students</h2>
            <p className="text-lg text-slate-600">Join hundreds of confident drivers who started with us</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <Card className="border-0 shadow-soft hover-lift rounded-2xl glass">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/maria-santos-profile-2Ynsen5ejgm5MZFzsfc7To.webp" alt="Maria Santos" className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <p className="font-semibold text-slate-900">Maria Santos</p>
                      <p className="text-xs text-slate-600">Beginner course</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 italic">
                  "MMSU made learning to drive so easy and stress-free. The instructors are patient and professional. Highly recommended!"
                </p>
              </CardContent>
            </Card>

            {/* Testimonial 2 */}
            <Card className="border-0 shadow-soft hover-lift rounded-2xl glass">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/juan-dela-cruz-profile-R7F39pDGBks3H8AzPdA3xX.webp" alt="Juan Dela Cruz" className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <p className="font-semibold text-slate-900">Juan Dela Cruz</p>
                      <p className="text-xs text-slate-600">Refresher course</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 italic">
                  "I passed my road test on the first try! The practical training was comprehensive and the cars are well-maintained."
                </p>
              </CardContent>
            </Card>

            {/* Testimonial 3 */}
            <Card className="border-0 shadow-soft hover-lift rounded-2xl glass">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/ana-reyes-profile-nu2TifctqbiW3uB6VdSPbj.webp" alt="Ana Reyes" className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <p className="font-semibold text-slate-900">Ana Reyes</p>
                      <p className="text-xs text-slate-600">Road test prep</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 italic">
                  "Best decision ever! The online course was flexible and the instructors were always available for questions."
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section id="location" className="py-12 md:py-24 bg-slate-50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
            {/* Map */}
            <div className="rounded-2xl md:rounded-3xl overflow-hidden shadow-lg md:shadow-2xl h-96 md:h-auto">
              <MapView 
                initialCenter={{ lat: 14.3167, lng: 121.3167 }}
                initialZoom={15}
              />
            </div>

            {/* Contact Info */}
            <div className="space-y-6 md:space-y-8">
              <div>
                <h2 className="text-2xl md:text-4xl font-bold text-slate-900 mb-2 md:mb-4">Visit Us Today</h2>
                <p className="text-base md:text-lg text-slate-600">
                  Located in the heart of Biñan, we're easy to reach. Drop by for a consultation or give us a call.
                </p>
              </div>

              <div className="space-y-4 md:space-y-6">
                {/* Address */}
                <div className="flex gap-3 md:gap-4 p-4 md:p-6 glass rounded-xl md:rounded-2xl border border-white/20 hover-lift">
                  <MapPin className="w-5 md:w-6 h-5 md:h-6 text-red-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1 text-sm md:text-base">Address</h3>
                    <p className="text-slate-600 text-sm md:text-base">Biñan, Laguna, Philippines</p>
                  </div>
                </div>

                {/* Phone */}
                <button 
                  onClick={handleCall}
                  className="w-full flex gap-3 md:gap-4 p-4 md:p-6 glass rounded-xl md:rounded-2xl border border-white/20 hover-lift text-left transition-all"
                >
                  <Phone className="w-5 md:w-6 h-5 md:h-6 text-red-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1 text-sm md:text-base">Phone</h3>
                    <p className="text-slate-600 text-sm md:text-base">{DISPLAY_PHONE}</p>
                    <p className="text-xs text-red-600 font-medium mt-1">Click to call now</p>
                  </div>
                </button>

                {/* Hours */}
                <div className="flex gap-3 md:gap-4 p-4 md:p-6 glass rounded-xl md:rounded-2xl border border-white/20 hover-lift">
                  <Clock className="w-5 md:w-6 h-5 md:h-6 text-red-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1 text-sm md:text-base">Hours</h3>
                    <p className="text-slate-600 text-sm md:text-base">Monday - Sunday: 6:00 AM - 8:00 PM</p>
                  </div>
                </div>
              </div>

              {/* CTA */}
              <a
                href="https://www.google.com/maps/dir/?api=1&destination=Biñan%20Laguna&travelmode=driving"
                target="_blank"
                rel="noopener noreferrer"
                className="block"
              >
                <Button className="w-full bg-red-600 hover:bg-red-700 text-white rounded-full px-8 py-6 text-base font-semibold hover-scale shadow-lg">
                  Get Directions
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-red-600 to-red-700 text-white">
        <div className="container text-center space-y-8">
          <h2 className="text-4xl md:text-5xl font-bold">Ready to Start Driving?</h2>
          <p className="text-lg text-red-50 max-w-2xl mx-auto">
            Book your first lesson today and take the first step toward becoming a confident driver.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button 
              onClick={() => setIsBookingOpen(true)}
              className="bg-white text-red-600 hover:bg-slate-100 rounded-full px-8 py-6 text-base font-semibold hover-scale"
            >
              Book Your First Lesson
            </Button>
            <Button 
              variant="outline" 
              onClick={handleCall}
              className="border-2 border-white text-white hover:bg-white/10 rounded-full px-8 py-6 text-base font-semibold hover-scale"
            >
              Call: {DISPLAY_PHONE}
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center overflow-hidden flex-shrink-0">
                  <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/mmsu2_5a2738c2.jpg" alt="MMSU Logo" className="w-full h-full object-cover" />
                </div>
                <div>
                  <h3 className="font-bold text-white">MMSU</h3>
                  <p className="text-xs">Driving School</p>
                </div>
              </div>
              <p className="text-sm">Making confident drivers since 2014.</p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold text-white mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#services" className="hover:text-red-400 transition-colors">Services</a></li>
                <li><a href="#faq" className="hover:text-red-400 transition-colors">FAQ</a></li>
                <li><a href="#reviews" className="hover:text-red-400 transition-colors">Reviews</a></li>
                <li><a href="#location" className="hover:text-red-400 transition-colors">Location</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-semibold text-white mb-4">Contact</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <button onClick={handleCall} className="hover:text-red-400 transition-colors">
                    Phone: {DISPLAY_PHONE}
                  </button>
                </li>
                <li>
                  <a href={`mailto:${EMAIL}`} className="hover:text-red-400 transition-colors">
                    {EMAIL}
                  </a>
                </li>
                <li>
                  <a href={`mailto:${EXECUTIVE_EMAIL}`} className="hover:text-red-400 transition-colors">
                    {EXECUTIVE_EMAIL}
                  </a>
                </li>
                <li>Biñan, Laguna, Philippines</li>
                <li>Mon-Sun: 6 AM - 8 PM</li>
              </ul>
            </div>

            {/* Social */}
            <div>
              <h4 className="font-semibold text-white mb-4">Follow Us</h4>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm hover:text-red-400 transition-colors">
                <Facebook size={20} />
                <span>Facebook</span>
              </a>
            </div>
          </div>

          <div className="border-t border-slate-700 pt-8 text-center text-sm">
            <p>&copy; 2026 MMSU Driving School. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Floating Call Button (Mobile) */}
      {showFloatingCTA && (
        <div className="fixed bottom-6 right-6 z-30 md:hidden">
          <Button 
            onClick={handleCall}
            className="bg-red-600 hover:bg-red-700 text-white rounded-full w-14 h-14 shadow-lg hover-scale flex items-center justify-center"
          >
            <Phone size={24} />
          </Button>
        </div>
      )}
    </div>
  );
}
