import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X } from "lucide-react";

interface BookingFormProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

// Branch configuration with Facebook Page IDs
const BRANCHES = {
  pasay: {
    name: "Pasay",
    pageId: "105966011970213",
    dmId: "1",
  },
  binan: {
    name: "Biñan",
    pageId: "100967935292701",
    dmId: "2",
  },
  calamba: {
    name: "Calamba",
    pageId: "107244661769652",
    dmId: "3",
  },
  las_pinas: {
    name: "Las Piñas",
    pageId: "104597645024257",
    dmId: "4",
  },
};

export function BookingForm({ isOpen, onOpenChange }: BookingFormProps) {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    courseType: "",
    selectedBranch: "",
    message: "",
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSelectChange = (value: string, fieldName: string) => {
    setFormData((prev) => ({
      ...prev,
      [fieldName]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const selectedBranchKey = formData.selectedBranch as keyof typeof BRANCHES;
    const branch = BRANCHES[selectedBranchKey];

    if (!branch) {
      alert("Please select a valid branch");
      return;
    }

    // Create booking message
    const bookingMessage = `
Hello MMSU Driving School,

I would like to book a driving lesson. Here are my details:

Full Name: ${formData.fullName}
Email: ${formData.email}
Phone: ${formData.phone}
Course Type: ${formData.courseType}
Branch: ${branch.name}

Additional Message:
${formData.message}

Please confirm my booking at your earliest convenience.

Thank you!
    `.trim();

    // Send via Facebook Messenger
    const facebookMessengerLink = `https://m.me/${branch.pageId}?text=${encodeURIComponent(bookingMessage)}`;
    
    // Also send via email as backup
    const subject = `Booking Request - ${formData.courseType} (${branch.name})`;
    const mailtoLink = `mailto:mmsudriving@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bookingMessage)}`;

    // Open Facebook Messenger first
    window.open(facebookMessengerLink, "_blank");
    
    // Also open email as backup
    setTimeout(() => {
      window.location.href = mailtoLink;
    }, 500);

    // Reset form and close dialog
    setFormData({
      fullName: "",
      email: "",
      phone: "",
      courseType: "",
      selectedBranch: "",
      message: "",
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] glass animate-slide-in-down">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-slate-900">
            Book Your First Lesson
          </DialogTitle>
          <DialogDescription className="text-slate-600">
            Fill in your details and we'll confirm your booking via Facebook Messenger.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          {/* Full Name */}
          <div className="space-y-2">
            <Label htmlFor="fullName" className="text-sm font-semibold">
              Full Name
            </Label>
            <Input
              id="fullName"
              name="fullName"
              placeholder="Juan Dela Cruz"
              value={formData.fullName}
              onChange={handleInputChange}
              required
              className="rounded-xl border-slate-200 focus:border-red-500 focus:ring-red-500"
            />
          </div>

          {/* Email */}
          <div className="space-y-2">
            <Label htmlFor="email" className="text-sm font-semibold">
              Email Address
            </Label>
            <Input
              id="email"
              name="email"
              type="email"
              placeholder="juan@example.com"
              value={formData.email}
              onChange={handleInputChange}
              required
              className="rounded-xl border-slate-200 focus:border-red-500 focus:ring-red-500"
            />
          </div>

          {/* Phone */}
          <div className="space-y-2">
            <Label htmlFor="phone" className="text-sm font-semibold">
              Phone Number
            </Label>
            <Input
              id="phone"
              name="phone"
              placeholder="0927 837 8111"
              value={formData.phone}
              onChange={handleInputChange}
              required
              className="rounded-xl border-slate-200 focus:border-red-500 focus:ring-red-500"
            />
          </div>

          {/* Course Type */}
          <div className="space-y-2">
            <Label htmlFor="courseType" className="text-sm font-semibold">
              Course Type
            </Label>
            <Select value={formData.courseType} onValueChange={(value) => handleSelectChange(value, "courseType")}>
              <SelectTrigger className="rounded-xl border-slate-200 focus:border-red-500 focus:ring-red-500">
                <SelectValue placeholder="Select a course" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="theoretical">Theoretical Driving Course (15-hour)</SelectItem>
                <SelectItem value="online-theoretical">Online Theoretical Driving Course (15-hour)</SelectItem>
                <SelectItem value="practical">Practical Driving Course (8-hour)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Select Branch */}
          <div className="space-y-2">
            <Label htmlFor="selectedBranch" className="text-sm font-semibold">
              Select Branch
            </Label>
            <Select value={formData.selectedBranch} onValueChange={(value) => handleSelectChange(value, "selectedBranch")}>
              <SelectTrigger className="rounded-xl border-slate-200 focus:border-red-500 focus:ring-red-500">
                <SelectValue placeholder="Choose your preferred branch" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pasay">Pasay</SelectItem>
                <SelectItem value="binan">Biñan</SelectItem>
                <SelectItem value="calamba">Calamba</SelectItem>
                <SelectItem value="las_pinas">Las Piñas</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Message */}
          <div className="space-y-2">
            <Label htmlFor="message" className="text-sm font-semibold">
              Additional Message (Optional)
            </Label>
            <Textarea
              id="message"
              name="message"
              placeholder="Tell us anything else we should know..."
              value={formData.message}
              onChange={handleInputChange}
              className="rounded-xl border-slate-200 focus:border-red-500 focus:ring-red-500 min-h-[100px]"
            />
          </div>

          {/* Submit Button */}
          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              className="flex-1 bg-red-600 hover:bg-red-700 text-white rounded-xl py-6 font-semibold hover-scale shadow-lg"
            >
              Send Booking Request
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="rounded-xl border-slate-200 hover:bg-slate-50"
            >
              <X size={20} />
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
