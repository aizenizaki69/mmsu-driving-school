import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * CarSlider Component - Auto-sliding with smooth transitions
 * Design Philosophy: Premium iOS 26 Aesthetic
 * - Auto-advance every 5 seconds with smooth fade/scale transitions
 * - Responsive height that fits images properly on all devices
 * - Mobile-optimized with touch-friendly controls
 * - Pauses on hover/interaction, resumes after 10 seconds
 */

interface CarSliderProps {
  title?: string;
  description?: string;
}

export function CarSlider({ title = "PDC Cars Available", description = "Explore our fleet of well-maintained vehicles" }: CarSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [carImages, setCarImages] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAutoPlay, setIsAutoPlay] = useState(true);

  // Load car images from public folder and CDN
  useEffect(() => {
    const loadCarImages = async () => {
      try {
        // Sample car images from CDN for testing
        const sampleImages = [
          "https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/car-1-sample-nHx2h5Gy9VPNuyfTewiYUU.webp",
          "https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/car-2-sample-ZzvPHGD4WjnxPYh4YezTRt.webp",
          "https://d2xsxph8kpxj0f.cloudfront.net/310519663516894564/Sw3ts9nCbfwRozck5BxwJA/car-3-sample-QrjTpioGMXubyMZrVhkLJ5.webp",
        ];
        
        const images: string[] = [...sampleImages];
        
        // Try to load additional images from public/cars/ folder
        for (let i = 1; i <= 10; i++) {
          try {
            const response = await fetch(`/cars/car-${i}.png`, { method: "HEAD" });
            if (response.ok) {
              images.push(`/cars/car-${i}.png`);
            }
          } catch {
            // Image doesn't exist, continue
          }
        }

        setCarImages(images);
        setIsLoading(false);
      } catch (error) {
        console.error("Error loading car images:", error);
        setIsLoading(false);
      }
    };

    loadCarImages();
  }, []);

  // Auto-advance slider every 3 seconds
  useEffect(() => {
    if (!isAutoPlay || carImages.length === 0) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % carImages.length);
    }, 3000); // 3 second delay for faster rotation

    return () => clearInterval(interval);
  }, [isAutoPlay, carImages.length]);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % carImages.length);
    setIsAutoPlay(false); // Stop auto-play when user manually navigates
    setTimeout(() => setIsAutoPlay(true), 10000); // Resume after 10 seconds
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + carImages.length) % carImages.length);
    setIsAutoPlay(false);
    setTimeout(() => setIsAutoPlay(true), 10000);
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
    setIsAutoPlay(false);
    setTimeout(() => setIsAutoPlay(true), 10000);
  };

  if (isLoading) {
    return (
      <div className="w-full aspect-video md:aspect-auto md:h-96 bg-gradient-to-br from-red-50 to-red-100 rounded-2xl flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading cars...</p>
        </div>
      </div>
    );
  }

  if (carImages.length === 0) {
    return (
      <div className="w-full aspect-video md:aspect-auto md:h-96 bg-gradient-to-br from-red-50 to-red-100 rounded-2xl flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600">No car images available</p>
          <p className="text-sm text-slate-500 mt-2">Add PNG images to public/cars/ folder</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Title and Description */}
      <div className="mb-8 text-center">
        <h2 className="text-4xl font-bold text-slate-900 mb-3">{title}</h2>
        <p className="text-lg text-slate-600">{description}</p>
      </div>

      {/* Main Slider */}
      <div 
        className="relative w-full aspect-video md:aspect-auto md:h-96 rounded-2xl overflow-hidden shadow-2xl group"
        onMouseEnter={() => setIsAutoPlay(false)} 
        onMouseLeave={() => setIsAutoPlay(true)}
      >
        {/* Images Container */}
        <div className="relative w-full h-full bg-gradient-to-br from-red-50 to-red-100">
          {carImages.map((image, index) => (
            <div
              key={index}
              className={`absolute w-full h-full transition-all duration-700 ease-in-out ${
                index === currentIndex
                  ? "opacity-100 scale-100"
                  : "opacity-0 scale-95"
              }`}
            >
              <img
                src={image}
                alt={`Car ${index + 1}`}
                className="w-full h-full object-cover"
                onError={(e) => {
                  // Fallback if image fails to load
                  const target = e.target as HTMLImageElement;
                  target.src = "/cars/placeholder-car.png";
                }}
              />
            </div>
          ))}

          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none"></div>

          {/* Car Counter */}
          <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur px-4 py-2 rounded-full">
            <p className="text-sm font-semibold text-slate-900">
              {currentIndex + 1} / {carImages.length}
            </p>
          </div>
        </div>

        {/* Previous Button */}
        <Button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-white/80 hover:bg-white text-slate-900 rounded-full p-2 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          size="icon"
        >
          <ChevronLeft size={24} />
        </Button>

        {/* Next Button */}
        <Button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-white/80 hover:bg-white text-slate-900 rounded-full p-2 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          size="icon"
        >
          <ChevronRight size={24} />
        </Button>
      </div>

      {/* Dot Indicators */}
      <div className="flex justify-center gap-2 mt-8">
        {carImages.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`h-3 rounded-full transition-all duration-300 ${
              index === currentIndex
                ? "bg-red-600 w-8"
                : "bg-slate-300 hover:bg-slate-400 w-3"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>


    </div>
  );
}
